exports.healthCheckInitiator = (event, context, callback) => {

  var http = require('http');
  var fs = require('fs');
  var node_ssh = require('node-ssh');
  var tmp = require('tmp');
  var aws = require('aws-sdk');

  var ssh = new node_ssh();
  var ec2 = new aws.EC2();
  var ec2Params = {
    Filters: [
      {Name: 'instance-state-name', Values: ['running']},
      {Name: 'tag:Deployment', Values:['deployer-*']}
  ]};

  ec2.describeInstances(ec2Params, function (err, data) {
    data.Reservations.forEach(function (res) {
      res.Instances.forEach(function (instance) {
        let deployment = instance.Tags.filter(function (tag) {
            return tag.Key == 'Deployment';
        })[0];

        let path = '';

        http.get({
          host: instance.PublicDnsName,
          port: '7777',
          path: path.concat('/v1/deployments/', deployment.Value, '/ssh_key'),
          method: 'GET'
        }, function(response) {
          var body = '';
          response.setEncoding('utf8');
          response.on("data", function(chunk) {
              body += chunk;
          });
          response.on("end", function() {
            tmp.file({ mode: 0644, prefix: 'deployer', postfix: '.pem' }, function _tempFileCreated(err, path, fd) {
              ssh.connect({
                host: instance.PublicDnsName,
                username: 'ec2-user',
                privateKey: fs.readFileSync(path,'utf8')
              }).then(function() {
                ssh.execCommand('echo "Hello"', { cwd:'/home/ec2-user' }).then(function(result) {
                  callback(null, 'Execute health-check.sh successfully: '.concat(result));
                })
              });
            });
          });
        }).on('error' , function (error) {
          callback(error, null);
        });
      });
    });
  });
};
